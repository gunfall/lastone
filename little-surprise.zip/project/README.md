# A Little Surprise for Her ♡

## Run it
- Quick look: double-click `index.html`.
- Best (and needed for music on some phones): run `python3 -m http.server 8000` in this folder, open http://localhost:8000
- To open on her phone: upload the whole folder to a free host (Netlify Drop, GitHub Pages, Cloudflare Pages) and send the link.
- Fonts (Gaegu + Caveat) load from Google Fonts, so the first open needs internet.

## Customize (all in script.js, top "SETTINGS" block)
- Password: `PASSWORD` (a playful gate only, not real security)
- Letter text + signature: `LETTER`
- Wrong-password message: `WRONG_PASSWORD_TEXT`
- Which stickers appear and where: `LAYOUTS` (file name, x %, y %, size, tilt)
- Music file: `MUSIC_FILE`  (or just replace assets/music.mp3)

## Photos / bouquet (index.html)
- Replace assets/girl-photo-1..4.jpg (1+2 on the left, 3+4 on the right), or change the `src` of the four <img> tags.
- Bouquet: assets/bouquet.png. Butterflies: assets/butterflies/.
- Wallpaper: assets/wallpaper.svg. Colours: variables at the top of style.css.
