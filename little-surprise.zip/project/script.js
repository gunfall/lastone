/* =========================================================
   A Little Surprise for Her ♡  ·  script.js
   Everything you might want to edit is in the SETTINGS block.
   ========================================================= */

/* ---------------------- SETTINGS ---------------------- */

// The password. NOTE: this is only a playful gate, NOT real security —
// anyone can read it by viewing the page source. (Capitals/spaces are ignored.)
const PASSWORD = "iloveyou";

// Shown when the password is wrong.
const WRONG_PASSWORD_TEXT = "oopsie~ that's not it ♡ try again!";

// Background music (the same file is used the whole time).
const MUSIC_FILE = "assets/music.mp3";

// The letter. Edit the words here ♡
const LETTER = {
  title: "to my favorite person ♡",
  paragraphs: [
    "i made this little website just for you.",
    "it's a small gift, but i hope it makes you smile.",
    "i just wanted to remind you that you're someone special to me, and i'm glad you're part of my life.",
    "i hope this little surprise makes your day a little better. ♡"
  ],
  signature: "From, Your Bb"
};

// Stickers in the cat world.  [file name, x %, y %, width (in vmin), tilt (deg)]
// Files live in assets/stickers/. "doodle-" cats bounce, the rest float gently.
// There are two layouts: one for tall (phone) screens, one for wide (desktop) screens.
const STICKER_DIR = "assets/stickers/";
const LAYOUTS = {
  portrait: [
    ["cat-01",    15, 10, 27, -5],
    ["doodle-01", 50,  6.5, 21, 3],
    ["cat-05",    84, 11, 29, 4],
    ["flower-03",  6, 27, 11, -8],
    ["cat-04",    29, 24, 22, -3],
    ["doodle-02", 68, 24.5, 20, 5],
    ["flower-11", 93, 28, 12, 6],
    ["pink-23",    5, 44, 9, -10],
    ["flower-05",  5, 59, 9, -4],
    ["pink-18",   95, 45, 9, 10],
    ["flower-08", 95, 60, 10, 5],
    ["cat-08",    20, 72, 29, -3],
    ["pink-06",   44, 71, 9, 8],
    ["pink-17",   60, 71, 10, -6],
    ["cat-10",    83, 73, 18, 4],
    ["cat-16",    18, 89, 27, -4],
    ["doodle-06", 50, 91, 25, 2],
    ["cat-11",    83, 88, 29, 3]
  ],
  landscape: [
    ["cat-01",     9, 15, 24, -5],
    ["cat-04",    27, 10, 18, 3],
    ["doodle-01", 45, 10, 15, -3],
    ["doodle-02", 62, 10, 16, 4],
    ["cat-05",    81, 13, 22, 3],
    ["flower-03", 94, 24, 9, 5],
    ["flower-01",  3, 34, 9, -6],
    ["pink-23",   22, 35, 7, -8],
    ["cat-08",    10, 47, 22, -3],
    ["cat-10",    24, 60, 13, 4],
    ["cat-02",    89, 46, 19, 3],
    ["pink-18",   77, 35, 6, 8],
    ["cat-09",    76, 62, 16, -3],
    ["flower-08", 96, 64, 8, 4],
    ["cat-11",    10, 80, 22, 3],
    ["doodle-06", 30, 86, 17, -2],
    ["pink-06",   44, 89, 7, 5],
    ["cat-16",    58, 85, 18, 3],
    ["doodle-07", 74, 88, 17, -3],
    ["cat-13",    91, 83, 22, 3]
  ]
};

/* ------------------- HELPERS / ELEMENTS ------------------- */
const $ = (sel) => document.querySelector(sel);
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

const scenes = { gate: $("#gate"), world: $("#world"), bouquet: $("#bouquet-scene") };
const fxLayer = $("#fx-layer");
let currentScene = "gate";

function showScene(name) {
  Object.entries(scenes).forEach(([key, el]) => el.classList.toggle("active", key === name));
  currentScene = name;
}

/* ------------------- HEARTS ------------------- */
const HEART = '<svg viewBox="0 0 32 30"><path fill="currentColor" d="M16 28.5C14 27 2 19 2 10.5 2 5.5 5.8 2 10 2c2.6 0 4.9 1.4 6 3.5C17.1 3.4 19.4 2 22 2c4.2 0 8 3.5 8 8.5 0 8.5-12 16.5-14 18z"/></svg>';
const HEART_COLORS = ["#e8456b", "#f4a3b5", "#c8274b", "#f27a95"];

function makeHeart(cls, styles) {
  const el = document.createElement("span");
  el.className = "fx-heart " + cls;
  el.innerHTML = HEART;
  Object.entries(styles).forEach(([k, v]) => el.style.setProperty(k, v));
  fxLayer.appendChild(el);
  return el;
}

function burstHearts(x, y, count = 10) {
  if (reduceMotion.matches) return;
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count + Math.random() * 0.5;
    const dist = 50 + Math.random() * 70;
    const el = makeHeart("burst", {
      "--x": x + "px", "--y": y + "px",
      "--s": 12 + Math.random() * 14 + "px",
      "--c": HEART_COLORS[i % HEART_COLORS.length],
      "--dx": Math.cos(angle) * dist + "px",
      "--dy": Math.sin(angle) * dist - 20 + "px"
    });
    setTimeout(() => el.remove(), 1000);
  }
}

// gentle hearts drifting up on the cat world + bouquet scenes
setInterval(() => {
  if (reduceMotion.matches || document.hidden) return;
  if (currentScene === "gate") return;
  if (fxLayer.querySelectorAll(".rise").length > 12) return;
  const dur = 8 + Math.random() * 5;
  const el = makeHeart("rise", {
    "--x": Math.random() * 96 + "%",
    "--s": 10 + Math.random() * 12 + "px",
    "--c": HEART_COLORS[Math.floor(Math.random() * HEART_COLORS.length)],
    "--t": dur + "s",
    "--sway": (Math.random() * 60 - 30) + "px"
  });
  setTimeout(() => el.remove(), dur * 1000 + 200);
}, 1500);

/* ------------------- MUSIC (one single Audio object) ------------------- */
const music = new Audio(MUSIC_FILE);
music.loop = true;
music.preload = "auto";
music.volume = 0.7;

const musicBtn = $("#music-btn");
const musicTip = $("#music-tip");
let userPaused = false;          // true once she pauses on purpose -> we never auto-start again

function updateMusicUI() {
  const playing = !music.paused;
  musicBtn.classList.toggle("playing", playing);
  musicBtn.setAttribute("aria-pressed", String(playing));
  musicBtn.setAttribute("aria-label", playing ? "pause music" : "play music");
  if (playing) musicTip.hidden = true;
}

function startMusic() {
  const p = music.play();
  if (p && p.catch) {
    p.catch(() => { musicTip.hidden = false; updateMusicUI(); });   // autoplay blocked -> let her tap the button
  }
}

musicBtn.addEventListener("click", () => {
  if (music.paused) { userPaused = false; startMusic(); }
  else { userPaused = true; music.pause(); }
});
music.addEventListener("play", updateMusicUI);
music.addEventListener("pause", updateMusicUI);

/* ------------------- 1 · PASSWORD GATE ------------------- */
const gateForm = $("#gate-form");
const pwInput = $("#pw");
const gateError = $("#gate-error");

function normalize(s) { return s.trim().toLowerCase(); }

gateForm.addEventListener("submit", (e) => {      // pressing Enter submits the form too
  e.preventDefault();
  if (normalize(pwInput.value) === normalize(PASSWORD)) {
    gateError.textContent = "";
    const r = gateForm.getBoundingClientRect();
    burstHearts(r.left + r.width / 2, r.top + r.height / 2, 14);
    musicBtn.hidden = false;
    if (!userPaused) startMusic();                // started inside the click/Enter = browsers allow it
    updateMusicUI();
    enterWorld();
  } else {
    gateError.textContent = WRONG_PASSWORD_TEXT;
    gateForm.classList.remove("shake");
    void gateForm.offsetWidth;                    // restart the shake animation
    gateForm.classList.add("shake");
    pwInput.select();
  }
});

/* ------------------- 2 · CAT + FLOWER WORLD ------------------- */
const stickerLayer = $("#sticker-layer");
const portraitQuery = window.matchMedia("(orientation: portrait)");

function renderStickers() {
  const list = portraitQuery.matches ? LAYOUTS.portrait : LAYOUTS.landscape;
  stickerLayer.innerHTML = "";
  list.forEach(([file, x, y, w, rot], i) => {
    const sticker = document.createElement("div");
    sticker.className = "sticker" + (file.startsWith("doodle") ? " bouncy" : "");
    sticker.style.cssText =
      `--x:${x}%; --y:${y}%; --w:${w}; --r:${rot}deg; --i:${i};` +
      `--dur:${(3.4 + Math.random() * 2.2).toFixed(2)}s; --delay:${(-Math.random() * 4).toFixed(2)}s`;
    const pop = document.createElement("div");
    pop.className = "pop";
    const img = document.createElement("img");
    img.src = `${STICKER_DIR}${file}.png`;
    img.alt = "";
    img.draggable = false;
    pop.appendChild(img);
    sticker.appendChild(pop);
    // tap a sticker = little wiggle + a few hearts
    sticker.addEventListener("click", () => {
      pop.classList.remove("wiggle"); void pop.offsetWidth; pop.classList.add("wiggle");
      const r = sticker.getBoundingClientRect();
      burstHearts(r.left + r.width / 2, r.top + r.height / 2, 5);
    });
    stickerLayer.appendChild(sticker);
  });
}

function enterWorld() {
  renderStickers();
  showScene("world");
  // let the scene fade in, then pop the stickers in one by one
  requestAnimationFrame(() => setTimeout(() => stickerLayer.parentElement.classList.add("world-in"), 250));
}
portraitQuery.addEventListener("change", () => {
  if (currentScene === "world") renderStickers();
});

$("#click-me").addEventListener("click", (e) => {
  burstHearts(e.clientX || window.innerWidth / 2, e.clientY || window.innerHeight / 2, 12);
  showScene("bouquet");
});

/* ------------------- 3 · BOUQUET → LETTER ------------------- */
const overlay = $("#letter-overlay");
const bouquetBtn = $("#bouquet");

// fill the letter from the LETTER settings
$("#letter-title").textContent = LETTER.title;
$("#letter-body").innerHTML = "";
LETTER.paragraphs.forEach((text) => {
  const p = document.createElement("p");
  p.textContent = text;
  $("#letter-body").appendChild(p);
});
$("#letter-sign").textContent = LETTER.signature;

function openLetter() {
  const r = bouquetBtn.getBoundingClientRect();
  burstHearts(r.left + r.width / 2, r.top + r.height * 0.3, 12);
  overlay.classList.add("open");
  overlay.setAttribute("aria-hidden", "false");
  overlay.querySelector(".letter-scroll").scrollTop = 0;
  setTimeout(() => $("#letter-close").focus({ preventScroll: true }), 50);
}

function closeLetter() {
  overlay.classList.remove("open");
  overlay.setAttribute("aria-hidden", "true");
  bouquetBtn.focus({ preventScroll: true });      // back to the bouquet — nothing else is reset
}

bouquetBtn.addEventListener("click", openLetter);
$("#letter-close").addEventListener("click", closeLetter);
overlay.addEventListener("click", (e) => { if (e.target === overlay) closeLetter(); });   // tap outside the paper
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && overlay.classList.contains("open")) closeLetter();
});
